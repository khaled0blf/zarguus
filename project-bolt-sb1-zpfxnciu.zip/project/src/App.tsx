import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import FeaturedProducts from './components/FeaturedProducts';
import Newsletter from './components/Newsletter';

function App() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <main>
        <Hero />
        <FeaturedProducts />
        <Newsletter />
      </main>
      <footer className="bg-gray-100 py-8 text-center text-gray-600">
        <p>© 2024 KHOULOUD TOUCHES. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default App;