import React from 'react';

export default function Hero() {
  return (
    <div className="relative h-[90vh] flex items-center">
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&q=80"
          alt="Elegant store display"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40"></div>
      </div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-white">
        <h1 className="text-5xl md:text-7xl font-serif mb-6">Discover Elegance</h1>
        <p className="text-xl md:text-2xl mb-8 max-w-2xl">
          Explore our curated collection of unique pieces that blend artistry with sophistication.
        </p>
        <button className="bg-white text-black px-8 py-3 text-lg font-medium hover:bg-gray-100 transition-colors">
          Shop Now
        </button>
      </div>
    </div>
  );
}